import { createApp } from 'vue'
import './style.css'
import 'tailwindcss/index';
import App from './App.vue'


createApp(App).mount('#app')
